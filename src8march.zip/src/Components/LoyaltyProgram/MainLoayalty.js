import React  from "react";
import LoayaltyProgramlist from "./LoayaltyProgramlist";

const MainLoayalty = () => {
  return (
    <>
      <div className="q-category-main-page">
            <LoayaltyProgramlist />
      </div>
    </>
  );
};

export default MainLoayalty;
