import React from 'react'

const SetupLogic = () => {
  


  return (
    <div>
      
    </div>
  )
}

export default SetupLogic
