import React from 'react'
import StoreCateUser from './StoreCateUser'

const MainInventoryDuplicate = () => {
  return (
   <div className=''>
    <StoreCateUser />

   </div>
  )
}

export default MainInventoryDuplicate
