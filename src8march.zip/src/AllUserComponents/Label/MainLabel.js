import React from 'react'

const MainLabel = () => {
  return (
    <div>MainLabel</div>
  )
}

export default MainLabel