import React from 'react'

const MainUsers = () => {
  return (
    <div>MainUsers</div>
  )
}

export default MainUsers