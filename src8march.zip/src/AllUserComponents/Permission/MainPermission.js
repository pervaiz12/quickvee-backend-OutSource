import React from 'react'
import PermissionList from '../../Components/Permission/PermissionList'

const MainPermission = () => {
  return (
    <div className="q-attributes-main-page">
       <div className="box">

       <PermissionList />
       </div>

     
    </div>
  )
}

export default MainPermission