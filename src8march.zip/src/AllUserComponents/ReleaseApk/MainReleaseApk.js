import React from 'react'

const MainReleaseApk = () => {
  return (
    <div>MainReleaseApk</div>
  )
}

export default MainReleaseApk