import React from 'react'

const SettingSetupSlice = () => {
  return (
    <div>
      
    </div>
  )
}

export default SettingSetupSlice
