import React from 'react';
import ReorderInventoryList from './ReorderInventoryList'

const ReorderInventoryMain = () => {

    return (
        <>
            
                <div className="q-order-main-page">
                    <ReorderInventoryList />
                </div>
            
        </>
    )
}

export default ReorderInventoryMain