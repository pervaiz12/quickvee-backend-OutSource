import React, { useState } from "react";
import BarCharts from "./BarCharts";

const NetSales = () => {


  return (
    <>
      <div className="box">
        <div
          className="box_shadow_div mt_card_header">
          <BarCharts />
        </div>
      </div>
    </>
  );
};

export default NetSales;
