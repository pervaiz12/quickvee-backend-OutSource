import React from 'react'

import PermissionList from './PermissionList'

function MainPermission() {
    return (
        <>
          <div className="q-attributes-main-page">
          <PermissionList/>
          </div>
        </>
    )
}

export default MainPermission