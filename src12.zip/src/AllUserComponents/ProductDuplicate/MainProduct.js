import React from 'react'
import ProductDuplicateStore from './ProductDuplicateStore'

const MainProduct = () => {
  return (
   <>
   <div className='q-order-main-page'>

    <ProductDuplicateStore />
   </div>
   
   </>
  )
}

export default MainProduct