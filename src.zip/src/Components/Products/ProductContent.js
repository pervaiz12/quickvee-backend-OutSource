import React from "react";
import { BsDot } from "react-icons/bs";

const ProductContent = () => {
  return (
    <>
   
        <div className="q-attributes-top-detail-section">
          <li>After you've made changes to your menu, select the option "Request Approval" to get admin approval to update your website.</li>
        </div>
     
      
    
    </>
  );
};

export default ProductContent;
