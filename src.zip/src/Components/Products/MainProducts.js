import React from 'react'
import FilterProduct from './FilterProduct'
import ProductContent from './ProductContent'
import ProductTable from './ProductTable'

const MainProducts = () => {
  return ( <>
{/* <FilterProduct /> */}
<ProductContent />
<ProductTable />


</>
  )
}

export default MainProducts