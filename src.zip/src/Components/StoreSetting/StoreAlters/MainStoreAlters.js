import React from 'react';
import SettingStoreAlters from '../StoreAlters/SettingStoreAlters';

const MainStoreAlters = () => {
    return (
      <>
        <SettingStoreAlters />
      </>
    )
  }
  
  export default MainStoreAlters
