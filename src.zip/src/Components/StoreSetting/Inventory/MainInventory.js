import React from "react";
import InventoryView from './InventoryView'
function MainInventory() {
  return (
    <>
      <div className="q-attributes-main-page">
        <InventoryView />
        </div>
    </>
  );
}

export default MainInventory;
