import React from 'react';
import SettingStoreOption from './SettingStoreOption';

const MainStoreOption = () => {
    return (
      <>
        <SettingStoreOption />
      </>
    )
  }
  
  export default MainStoreOption