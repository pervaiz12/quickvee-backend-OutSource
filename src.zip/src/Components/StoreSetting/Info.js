import React from 'react'

const Info = () => {
  return (
    
    <div>Info</div>
  )
}

export default Info