import { useState , useRef, useEffect } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import Validation from "../../../Constants/Validation";
import { BASE_URL, UPDATE_REGISTER_SETTINGS } from "../../../Constants/Config";

const RegisterSettingFormLogic = ({RegisterSettings}) => {
    
    const RegisterSettings_data = RegisterSettings.RegisterSettingsData;
    // console.log(RegisterSettings_data);
    const { isNumber ,validateRadioBtn, isText} = Validation();
    const [submitmessage, setsubmitmessage] = useState("");
    // const Navigate = useNavigate();
    const scrollRef = useRef(null);
    const [showModal, setShowModal] = useState(false);

    const [values, setValues] = useState({
        regi_setting:"",
        ebt_type:"",
        idel_logout: "",
        device_name:"",
        customer_loyalty:"",
        barcode_msg:"",
        round_invoice:"",
        discount_prompt:"",
        denomination:15,
        errors: {
            regi_setting:"",
            ebt_type:"",
            idel_logout: "",
            device_name: "",
            customer_loyalty:"",
            barcode_msg:"",
            round_invoice:"",
            discount_prompt:"",
            denomination:"",
        },
      }); 
    
      useEffect(() => {
        setValues((prevValues) => ({
          ...prevValues,
          regi_setting:RegisterSettings_data && RegisterSettings_data.regi_setting ? RegisterSettings_data.regi_setting : "",
          ebt_type:RegisterSettings_data && RegisterSettings_data.ebt ? RegisterSettings_data.ebt : "",
          idel_logout:  RegisterSettings_data && RegisterSettings_data.idel_logout ? RegisterSettings_data.idel_logout : "",
          device_name:  RegisterSettings_data && RegisterSettings_data.device_name ? RegisterSettings_data.device_name : "",
          customer_loyalty: RegisterSettings_data && RegisterSettings_data.customer_loyalty ? RegisterSettings_data.customer_loyalty : "",
          barcode_msg: RegisterSettings_data && RegisterSettings_data.barcode_msg ? RegisterSettings_data.barcode_msg : "",
          round_invoice: RegisterSettings_data && RegisterSettings_data.round_invoice ? RegisterSettings_data.round_invoice : "",
          discount_prompt: RegisterSettings_data && RegisterSettings_data.discount_prompt ? RegisterSettings_data.discount_prompt : "",
          // denomination: RegisterSettings_data && RegisterSettings_data.denomination ? parseInt(RegisterSettings_data.denomination) : "",
          
        }));
    console.log(values.denomination)
      }, [RegisterSettings_data])

      const handleRegisterSettingInput = async (event) => {
        let { errors } = values;
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        // console.log(values.ebt_type)
        // console.log(fieldValue)
        switch (fieldName) {
            case "idel_logout":
                await isNumber(fieldValue,fieldName, errors);
                break;
            case "device_name":
                await isText(fieldValue,fieldName, errors);
                break;
            case "denomination":
              // console.log(values)
              // console.log(event.target.value)
              // // let newval = (event.target.value == 1) ? 0 : 1;
              // let newval = event.target.value === "1" ? "0" : "1";
              // console.log(newval)
              // setValues({
              //   ...values, // Spread the existing state
              //   denomination: newval, // Update only the permissions property
              //   });
              //   console.log(values)
              // break;
              // let denominationArray = (values.denomination) ? values.denomination.split(',') : [];
              // console.log(denominationArray)
              // if (denominationArray.includes(event.target.value)) {
              //   denominationArray = denominationArray.filter(item => item !== event.target.value);
              // } else {
              //   denominationArray.push(event.target.value);
              // }
              // const updateddenomination = denominationArray.join(',');
              // console.log(updateddenomination)
              // setValues({
              //     ...values, // Spread the existing state
              //     denomination: updateddenomination, // Update only the permissions property
              // });
              
              break;
            case "regi_setting[]":
                let regi_settingsArray = (values.regi_setting) ? values.regi_setting.split(',') : [];
                // console.log(regi_settingsArray)
                if (regi_settingsArray.includes(event.target.value)) {
                  regi_settingsArray = regi_settingsArray.filter(item => item !== event.target.value);
                } else {
                  regi_settingsArray.push(event.target.value);
                }
                const updatedregi_setting = regi_settingsArray.join(',');
                // console.log(updatedregi_setting)
                setValues({
                    ...values, // Spread the existing state
                    regi_setting: updatedregi_setting, // Update only the permissions property
                });
                
                break;
            case "ebt_type[]":
                let ebt_typeArray = (values.ebt_type) ? values.ebt_type.split(',') : [];
                if (ebt_typeArray.includes(event.target.value)) {
                  ebt_typeArray = ebt_typeArray.filter(item => item !== event.target.value);
                } else {
                  ebt_typeArray.push(event.target.value);
                }
                const update_ebt_type = ebt_typeArray.join(',');
                setValues({
                    ...values, // Spread the existing state
                    ebt_type: update_ebt_type, // Update only the permissions property
                });
                break;
            default:
                break;
        }
    
        setValues((prevValues) => ({
          errors,
          ...prevValues,
          [fieldName]: fieldValue,
        }));
      };

useEffect(() => {
console.log(values)
}, [values])

      const handleRegisterSettingSubmit = async (e) => {
        e.preventDefault();
        let { errors } = values;
        await isNumber(values.idel_logout,'idel_logout', errors);
        await isText(values.device_name,'device_name', errors);
        // await isNumber(values.paid_breaks,'paid_breaks', errors);
        // await validateRadioBtn(values.role,errors);
    
        if (errors.idel_logout === "" && errors.device_name === ""   ) {
          const data = {
            "merchant_id":"MAL0100CA",
            "regi_setting":values.regi_setting,
            "ebt":values.ebt_type,
            "idel_logout":values.idel_logout,
            "discount_prompt":values.discount_prompt,
            "round_invoice":values.round_invoice,
            "customer_loyalty":values.customer_loyalty,
            "device_name":values.device_name,
            "barcode_msg":values.barcode_msg,
            "denomination":values.denomination,
          }
          // console.log(data);
          try {
            const response = await axios.post(BASE_URL + UPDATE_REGISTER_SETTINGS, data, { headers: { "Content-Type": "multipart/form-data" } })
            
            if ( response.data.status === true) {
              setsubmitmessage(response.data.message);
            }
            else {
               setsubmitmessage(response.data.message);
            }
          } catch (error) {
            // console.log('33 catch err');
            return new Error(error)
          }
        }
    
        setValues((prevState) => ({
          ...prevState,
          errors,
        }));
      };

      return { handleRegisterSettingInput, values, handleRegisterSettingSubmit, submitmessage, setsubmitmessage , showModal , setShowModal , scrollRef  };
}

export default RegisterSettingFormLogic;