import React from "react";
import EmployeeList from "./EmployeeList";

const MainAddEmployee = () => {
    return (
      <>
        <div className="q-attributes-main-page">
        <EmployeeList/>
        </div>
      </>
    )
  }

export default MainAddEmployee;