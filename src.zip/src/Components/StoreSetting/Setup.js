import React from 'react'

const Setup = () => {
  return (
    <div>Setup</div>
  )
}

export default Setup