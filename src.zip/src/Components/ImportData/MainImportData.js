import React from 'react'
import ImportData from './ImportData'
import Csvimport from './Csvimport'

const MainImportData = () => {
  return (
   <>
   <ImportData />
   <Csvimport />
   
   </>
  )
}

export default MainImportData


