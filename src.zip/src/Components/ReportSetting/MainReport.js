import React from 'react'

const MainReport = () => {
  return (
    <div>MainReport</div>
  )
}

export default MainReport