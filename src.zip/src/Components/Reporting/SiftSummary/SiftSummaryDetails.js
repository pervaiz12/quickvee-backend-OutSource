import React from "react";

const SiftSummaryDetails = () => {
  return (
    <>
      <div className="q-daily-report-bottom-report-header">
        <p className="report-sort">Date</p>
        <p className="report-sort">Station Name</p>
        <p className="report-sort"> Employee Name</p>
        <p className="report-sort"> Expected Cash ($)</p>
        <p className="report-sort"> Actual Cash ($)</p>
      </div>

      <div className="q-category-bottom-categories-listing">
        <div className="q-category-bottom-categories-single-category">
          <p className="report-sort">hello</p>
          <p className="report-sort">hello</p>
          <p className="report-sort">hello</p>
          <p className="report-sort">hello</p>
          <p className="report-sort">hello</p>
        </div>
      </div>
    </>
  );
};

export default SiftSummaryDetails;
