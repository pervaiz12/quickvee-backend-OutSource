import React from "react";

const Itemdatadetails = () => {
  return (
    <>
      <div className="q-attributes-bottom-detail-section">
        <div className="">
          <div className="q-attributes-bottom-header">
         
          </div>
          <div className="q-attributes-bottom-attriButes-header">
            <p className="q-employee-item">Name</p>
            <p className="q-employee-in"># Of Payments </p>
            <p className="q-employee-in"> Net Revenue Without Tips</p>
            <p className="q-employee-in"> Tips</p>
            <p className="q-employee-in"> Net Revenue With Tips</p>

            <p className="q-employee-out">Details</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in"> Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>

            <p className="q-employee-out">29</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in"> Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
              <p className="q-employee-out">29</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in"> Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
                <p className="q-employee-out">29</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in"> Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            <p className="q-employee-out">29</p>

         
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in"> Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            <p className="q-employee-out">29</p>

        
          </div>
        </div>
      </div>
    </>
  );
};

export default Itemdatadetails;
