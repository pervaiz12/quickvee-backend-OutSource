import React from 'react'

const ItemSalesDetails = () => {
  return (
  <>
<div className=''>
<div className="q-attributes-bottom-detail-section">
        <div className="q-attributes-bottom-header-sticky">
          <div className="q-attributes-bottom-header">
            <span>Item Sales Report</span>
          </div>
          <div className="q-attributes-bottom-attriButes-header">
            <p className="q-employee-item">Category</p>
            <p className="q-employee-in">	Name </p>
            <p className="q-employee-in"># Sold</p>
            <p className="q-employee-in">Gross Sales</p>
            <p className="q-employee-in">Price Override</p>
            
            <p className="q-employee-out">Discounts</p>
            <p className="q-employee-worked">Default Tax</p>
            <p className="q-catereport-break">Other Tax</p>
            <p className="q-catereport-break">Refunded</p>
            <p className="q-catereport-break">	Net Sales</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>  <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>  <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>  <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
          <p className="q-employee-item">01-01-2024</p>
            <p className="q-employee-in">02:07:12 am </p>
            <p className="q-employee-in">	Vikas Mishra</p>
            <p className="q-employee-in">lfbar</p>
            <p className="q-employee-in">strawberry</p>
            
            <p className="q-employee-out">29</p>
            <p className="q-employee-worked">	5</p>
            <p className="q-catereport-break">34</p>
            <p className="q-catereport-break">1.00</p>
            <p className="q-catereport-break">5</p>
          </div>
        </div>
      </div>
    
    </div>  
  
  
  
  
  </>
  )
}

export default ItemSalesDetails