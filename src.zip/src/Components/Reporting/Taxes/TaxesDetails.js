import React from 'react'

const TaxesDetails = () => {
  return (
    <>
      <div className="q-attributes-bottom-detail-section">
        <div className="">
          <div className="q-attributes-bottom-header">
         
          </div>
          <div className="q-attributes-bottom-attriButes-header">
            <p className="q-employee-item">Tax or Fee</p>
            <p className="q-employee-in">Tax Rate or Fee</p>
            <p className="q-employee-in"> Tax or Fee Refunded</p>
            <p className="q-employee-in"> 	Tax or Fee Collected</p>
            <p className="q-employee-in"> Net Revenue With Tips</p>

           
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
          <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">Sales Tax </p>
            <p className="q-employee-in"> 7.50%</p>
            <p className="q-employee-in">$0.00</p>
            <p className="q-employee-in">$1620.98 </p>
           
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
        <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">Sales Tax </p>
            <p className="q-employee-in"> 7.50%</p>
            <p className="q-employee-in">$0.00</p>
            <p className="q-employee-in">$1620.98 </p>
           
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
        <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">Sales Tax </p>
            <p className="q-employee-in"> 7.50%</p>
            <p className="q-employee-in">$0.00</p>
            <p className="q-employee-in">$1620.98 </p>
           
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
        <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">Sales Tax </p>
            <p className="q-employee-in"> 7.50%</p>
            <p className="q-employee-in">$0.00</p>
            <p className="q-employee-in">$1620.98 </p>
           
          </div>
        </div>
        <div className="q-attributes-bottom-attriButes-listing">
        <div className="q-employee-bottom-attriButes-single-attributes">
            <p className="q-employee-item">name item</p>
            <p className="q-employee-in">Sales Tax </p>
            <p className="q-employee-in"> 7.50%</p>
            <p className="q-employee-in">$0.00</p>
            <p className="q-employee-in">$1620.98 </p>
           
          </div>
        </div>
      </div>
    </>
  )
}

export default TaxesDetails