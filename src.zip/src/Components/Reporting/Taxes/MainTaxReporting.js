import React from 'react'
import MainTaxesReport from './MainTaxesReport'

const MainTaxReporting = () => {
  return (
  <>
  <div className=''>
    <MainTaxesReport />
  </div>
  
  </>
  )
}

export default MainTaxReporting
