import React from 'react'

const ShiftSummarySlice = () => {
  return (
    <div>
      
    </div>
  )
}

export default ShiftSummarySlice
