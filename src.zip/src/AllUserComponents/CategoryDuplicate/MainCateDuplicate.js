import React from 'react'
import CateDuplicateStore from './CateDuplicateStore'

const MainCateDuplicate = () => {
  return (
    <>
    <div className=''>
      <CateDuplicateStore />
    </div>
    
    </>
  )
}

export default MainCateDuplicate