import React from 'react'

const MainMerchantDetails = () => {
  return (
    <div>MainMerchantDetails</div>
  )
}

export default MainMerchantDetails