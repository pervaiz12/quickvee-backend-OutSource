import React from 'react'
import PermissionList from '../../Components/Permission/PermissionList'

const MainPermission = () => {
  return (
    <div className="q-attributes-main-page">
      <PermissionList />
    </div>
  )
}

export default MainPermission