// import React from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// import MainHome from './Components/Home/MainHome';
// import AddCategory from './Components/Category/AddCate';
// // import DashboardMain from './Components/Dashboard/DashboardMain';


// const Main = () => {
//   return (
//       <Routes>
       
//         <Route path="/" element={<MainHome  visible ={"dashboard"}/>} />
//         <Route path="/dashboard" element={<MainHome visible={"dashboard"} />} />
//         <Route path="/order" element={<MainHome visible={"order"} />} />
//         <Route  path="/category" element={<MainHome visible={"category"} />} />
//         <Route path="/purchase-data" element={<MainHome visible={"purchase-data"} />} />
//         <Route path="/products" element={<MainHome visible={"products"} />} />
//         <Route path="/attributes" element={<MainHome visible={"attributes"} />} />
//         <Route path="/import-data" element={<MainHome visible={"import-data"} />} />
//         <Route path="/coupons" element={<MainHome visible={"coupons"} />} />
//         <Route path="/vendors" element={<MainHome visible={"vendors"} />} />
//         <Route path="/timesheet" element={<MainHome visible={"timesheet"} />} />
//         <Route exact path="/addCategory" element={<AddCategory />} />
        
       
//       </Routes>
      
//   );
// };

// export default Main;

