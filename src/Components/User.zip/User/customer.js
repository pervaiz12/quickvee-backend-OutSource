import React from 'react'

export default function Customer() {
  return (
    <div className='box_shadow_div'>
    <div className='table_main_area'>
      <div className='table_header_sticky'>
        <div className='table_header_top'>
          <h1>Table Area</h1>
        </div>
        <div className='table_header'>
          <p className='table25'>Name</p>
          <p className='table30'>Email</p>
          <p className='table20'>Phone</p>
          <p className='table20'>User Type</p>
          <p className='table5'>Action</p>
        </div>
      </div>
        <div className='table_body'>
          <div className='table_row'>
            <p className='table25'>Name</p>
            <p className='table30'>Email</p>
            <p className='table20'>phone</p>
            <p className='table20'>User Type</p>
            <p className='table5'>User Type</p>
            {/* <p className='table10'>
              <img className="icon_img" alt="edit" src={Edit} />
            </p> */}
            
          </div>
          
        </div>
      </div>
  </div>
  )
}
